=== FormyChat Ultimate ===
Contributors: wppool,iamjafran
Donate link: https://wppool.dev
Requires at least: 5.0
Tested up to: 6.3
Requires PHP: 5.6
Stable tag: 2.1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Unlocks FormyChat Premium features upon license activation.

== Description ==
Unlocks FormyChat Premium features upon license activation.
        