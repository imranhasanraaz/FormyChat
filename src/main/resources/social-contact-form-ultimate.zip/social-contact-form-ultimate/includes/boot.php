<?php
/**
 * Boot file for FormyChat Ultimate
 *
 * @package SocialContactFormUltimate
 * @since 1.0.0
 */

// Define constants.
define( 'SCF_ULTIMATE_DIR', plugin_dir_path( SCF_ULTIMATE_FILE ) );
define( 'SCF_ULTIMATE_URL', plugin_dir_url( SCF_ULTIMATE_FILE ) );
define( 'SCF_ULTIMATE_INC', SCF_ULTIMATE_DIR . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR );
define( 'SCF_ULTIMATE_TEMPLATE', SCF_ULTIMATE_DIR . 'templates' . DIRECTORY_SEPARATOR );

// Require files.
require_once SCF_ULTIMATE_INC . 'classes/class-hooks.php';