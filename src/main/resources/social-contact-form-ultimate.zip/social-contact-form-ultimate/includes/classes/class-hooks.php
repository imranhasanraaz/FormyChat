<?php

/**
 * Class Hooks for FormyChat Ultimate
 *
 * @package SocialContactFormUltimate
 * @since 1.0.0
 */

// Namespace.
namespace WPPOOL\SCF\Ultimate;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( '\WPPOOL\SCF\Hooks' ) ) :
	/**
	 * Class Hooks
	 *
	 * @package SocialContactFormUltimate
	 * @since 1.0.0
	 */
	final class Hooks {

		/**
		 * Contains Appsero client
		 *
		 * @var mixed
		 */
		public $appsero;

		/**
		 * Contains if FormyChat Free version is installed
		 *
		 * @var bool
		 */
		public $scf_installed = false;

		/**
		 * Contains if FormyChat Ultimate version is activated
		 *
		 * @var bool
		 */
		public $scf_ultimate_activated = false;

		/**
		 * Constructor
		 */
		public function __construct() {
			register_deactivation_hook( SCF_ULTIMATE_FILE, [ $this, 'scf_ultimate_deactivate' ] );

			$this->init_appsero_client();
			add_action( 'init', [ $this, 'check_scf_installed' ] );

			add_action( 'admin_init', [ $this, 'safe_redirection_to_license_page' ], 10, 1 );
			add_action( 'admin_notices', [ $this, 'scf_ultimate_notice' ] );
			add_filter( 'is_scf_ultimate', [ $this, 'is_scf_ultimate' ], 10, 1 );

			if ( ! $this->scf_ultimate_activated ) {
				add_filter( 'scf_footer_text', [ $this, 'scf_footer_text' ], 10, 1 );
				add_filter( 'scf_form_meta', [ $this, 'extend_scf_form_meta' ], 10, 1 );
				add_filter( 'scf_localize_script', [ $this, 'scf_localize_script' ], 10, 1 );
				add_filter( 'scf_fields', [ $this, 'scf_fields' ], 10, 1 );
				add_filter( 'scf_preset_tags', [ $this, 'scf_preset_tags' ], 999, 1 );
			}

			add_filter( 'plugin_action_links_' . plugin_basename( SCF_ULTIMATE_FILE ), [ $this, 'plugin_action_links' ] );
		}

		/**
		 * Activation hook callback.
		 *
		 * @return void
		 */
		public function scf_ultimate_activate() {
			// Do nothing.
		}

		/**
		 * Deactivation hook callback.
		 *
		 * @return void
		 */
		public function scf_ultimate_deactivate() {
			delete_option( 'scf_ultimate_redirected' );
		}


		/**
		 * Safe redirection to license page
		 *
		 * @return void
		 */
		public function safe_redirection_to_license_page() {
			if ( ! $this->appsero->license()->is_valid() ) {
				if ( ! get_option( 'scf_ultimate_redirected' ) ) {
					update_option( 'scf_ultimate_redirected', true );
					wp_safe_redirect( admin_url( 'admin.php?page=scf-license' ) );
				}
			}
		}

		/**
		 * Check if SCF Free is installed
		 *
		 * @return void
		 */
		public function check_scf_installed() {
			$this->scf_installed          = class_exists( '\WPPOOL\SCF\Admin' );
			$this->scf_ultimate_activated = $this->appsero->license()->is_valid();
		}

		/**
		 * Prints notice if SCF Free is not installed
		 *
		 * @return mixed
		 */
		public function scf_ultimate_notice() {
			$notice = sprintf(
				__('%1$s requires %2$s to be installed and activated. Please install %3$s', 'social-contact-form-ultimate'),
				'<strong>' . __('FormyChat Ultimate', 'social-contact-form-ultimate') . '</strong>',
				'<strong>' . __('FormyChat', 'social-contact-form-ultimate') . '</strong>',
				'<a target="_blank" rel="noopener" href="' . esc_url(admin_url('plugin-install.php?s=Social+ Contact+Form+WPPOOL&tab=search&type=term')) . '">' . __('FormyChat', 'social-contact-form-ultimate') . '</a>'
			);
			if (!$this->scf_installed) {
				printf('<div class="notice notice-error is-dismissible"><p>%1$s</p></div>', $notice);
				return false;
			}
			

			$current_screen = get_current_screen();
			if ( ! $this->scf_ultimate_activated && 'scf-license' !== $current_screen->id ) {
				echo '<div class="notice notice-warning"><p>' . wp_sprintf( '<a class="text-indigo-500 underline" href="' . esc_url( admin_url( 'admin.php?page=scf-license' ) ) . '">Activate License</a> for FormyChat Ultimate and access all premium features.' ) . '</p></div>';
			}
		}

		/**
		 * Check if FormyChat Ultimate is activated
		 *
		 * @return bool
		 */
		public function is_scf_ultimate() {
			return true === wp_validate_boolean( $this->appsero->license()->is_valid() );
		}

		/**
		 * Footer text for FormyChat
		 *
		 * @return mixed
		 */
		public function scf_footer_text() {
			$footer_text = wp_sprintf('%s <a href="https://wppool.dev" target="_blank">%s</a>', esc_html__( 'Thanks for using FormyChat Pro by', 'social-contact-form-ultimate' ), esc_html__( 'WPPOOL', 'social-contact-form-ultimate' ));
			return $footer_text;
		}

		/**
		 * Extend SCF form meta
		 *
		 * @param mixed $scf_input_meta SCF form meta.
		 * @return mixed
		 */
		public function extend_scf_form_meta( $scf_input_meta ) {

			$scf_whatsapp = scf_get_option( 'whatsapp' );
			$meta         = [
				'whatsapp_number' => $scf_whatsapp['phone_number'],
			];

			if ( is_user_logged_in() ) {
				$meta['user_id']    = get_current_user_id();
				$user_info          = get_userdata( $meta['user_id'] );
				$meta['user_name']  = $user_info->user_login;
				$meta['user_email'] = $user_info->user_email;
			}

			$input_meta = array_merge( $scf_input_meta, $meta );

			return $input_meta;
		}


		/**
		 * Localize script for SCF
		 *
		 * @param mixed $scf_localize_script Localize script.
		 * @return mixed
		 */
		public function scf_localize_script( $scf_localize_script ) {
			$script = [
				'meta' => [
					'source' => get_the_permalink(),
				],
			];

			$localize_script = array_merge( $scf_localize_script, $script );

			return $localize_script;
		}

		/**
		 * Extend SCF fields
		 *
		 * @param mixed $scf_fields SCF fields.
		 * @return mixed
		 */
		public function scf_fields( $scf_fields ) {
			return $scf_fields;
		}

		/**
		 * Plugin action links for FormyChat Ultimate
		 *
		 * @param mixed $links Plugin action links.
		 * @return array
		 */
		public function plugin_action_links( $links ) {

			if ( function_exists( 'is_scf_ultimate' ) ) {
				$links[] = '<a href="' . admin_url( 'admin.php?page=scf-license' ) . '">' . __( 'License', 'social-contact-form-ultimate' ) . '</a>';
			}
			return $links;
		}

		/**
		 * Init Appsero client
		 *
		 * @return void
		 */
		public function init_appsero_client() {
			add_filter( 'appsero_is_local', '__return_false' );

			if ( ! class_exists( '\Appsero\Client' ) && file_exists( WP_PLUGIN_DIR . '/social-contact-form/includes/appsero/src/Client.php' ) ) {
				require_once WP_PLUGIN_DIR . '/social-contact-form/includes/appsero/src/Client.php';
			}

			$this->appsero = new \Appsero\Client( '6239ff91-6b41-4a6e-94a8-76a9671e13fa', 'FormyChat Ultimate', SCF_ULTIMATE_FILE );

			// Active insights.
			$this->appsero->insights()->hide_notice()->init();

			// Active automatic updater.
			$this->appsero->updater();

			// Active license page and checker.
			$args = [
				'type'        => 'submenu',
				'parent_slug' => 'formychat',
				// 'menu_title'  => function_exists( 'is_scf_ultimate' ) && is_scf_ultimate() ? __( 'License', 'social-contact-form-ultimate' ) : __( 'Activate License', 'social-contact-form-ultimate' ),
				'menu_title'  => __('License', 'social-contact-form-ultimate'),
				'page_title'  => 'Manage FormyChat Ultimate License',
				'menu_slug'   => 'scf-license',
				'position'    => 99,
			];

			$this->appsero->license()->add_settings_page( $args );
		}

		/**
		 * Add preset tags
		 *
		 * @param mixed $scf_preset_tags Preset tags.
		 * @return array
		 */
		public function scf_preset_tags( $scf_preset_tags ) {
			$tags = [
				'title' => __( 'Title', 'social-contact-form-ultimate' ),
				'url'   => __( 'URL', 'social-contact-form-ultimate' ),
				'id'    => __( 'ID', 'social-contact-form-ultimate' ),
			];

			$preset_tags = array_merge( $scf_preset_tags, $tags );

			return $preset_tags;
		}
	}

	// Initiate the class.
	new Hooks();
endif;