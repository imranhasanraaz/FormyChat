<?php

/**
 * FormyChat Pro loaders
 */

# Constants
define( 'SCF_ULTIMATE_DIR', plugin_dir_path( SCF_ULTIMATE_FILE ) );
define( 'SCF_ULTIMATE_URL', plugin_dir_url( SCF_ULTIMATE_FILE ) );
define( 'SCF_ULTIMATE_INC', SCF_ULTIMATE_DIR . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR );
define( 'SCF_ULTIMATE_TEMPLATE', SCF_ULTIMATE_DIR . 'templates' . DIRECTORY_SEPARATOR );

# Require files
if ( file_exists( SCF_ULTIMATE_INC . 'appsero/Client.php' ) && ! class_exists( '\SocialContactFormUltimateAppsero\Client' ) ) {
	require_once SCF_ULTIMATE_INC . 'appsero/Client.php';
} 
if ( file_exists( SCF_ULTIMATE_INC . 'class/class.hooks.php' ) ) {
	require_once SCF_ULTIMATE_INC . 'class/class.hooks.php';
} 