<?php

namespace WPPOOL\SCF\Ultimate;

if (!class_exists('\WPPOOL\SCF\Hooks')) :
	final class Hooks
	{

		public $scf_installed = false;
		public $scf_ultimate_activated = false;

		# Register hooks
		public function __construct()
		{
			// register_activation_hook( SCF_ULTIMATE_FILE, [$this, 'scf_ultimate_activate'] );
			register_deactivation_hook(SCF_ULTIMATE_FILE, [$this, 'scf_ultimate_deactivate']);
			add_action('admin_init', [$this, 'safe_redirection_to_license_page'], 10, 1);
			add_action('init', [$this, 'init_appsero_client']);
			add_action('init', [$this, 'check_scf_installed']);
			add_action('scf_setting_header', array($this, 'scf_ultimate_notice'), 10, 1);
			add_filter('is_scf_ultimate', array($this, 'is_scf_ultimate'), 10, 1);

			if (!$this->scf_ultimate_activated) {
				add_filter('scf_footer_text', array($this, 'scf_footer_text'), 10, 1);
				add_filter('scf_form_meta', array($this, 'extend_scf_form_meta'), 10, 1);
				add_filter('scf_localize_script', array($this, 'scf_localize_script'), 10, 1);
				add_filter('scf_fields', array($this, 'scf_fields'), 10, 1);
				add_filter('scf_preset_tags', [$this, 'scf_preset_tags'], 999, 1);
			}

			add_filter('plugin_action_links_' . plugin_basename(SCF_ULTIMATE_FILE), array($this, 'plugin_action_links'));
		}

		# activation hook
		public function scf_ultimate_activate()
		{
		}

		# deactivation hook
		public function scf_ultimate_deactivate()
		{
			delete_option('scf_ultimate_redirected');
		}


		public function safe_redirection_to_license_page()
		{
			if (!$this->appsero->license()->is_valid()) {
				if (!get_option('scf_ultimate_redirected')) {
					update_option('scf_ultimate_redirected', true);
					wp_redirect(admin_url('admin.php?page=scf-license'));
				}
			}
		}

		# Check if SCF is installed
		public function check_scf_installed()
		{
			$this->scf_installed = class_exists('\WPPOOL\SCF\Admin');
			$this->scf_ultimate_activated = $this->appsero->license()->is_valid();
		}

		# Check if SCF Pro is installed
		public function scf_ultimate_notice()
		{
			$notice = sprintf(
				__('%1$s requires %2$s to be installed and activated. Please install %3$s', 'social-contact-form-ultimate'),
				'<strong>' . __('FormyChat Ultimate', 'social-contact-form-ultimate') . '</strong>',
				'<strong>' . __('FormyChat', 'social-contact-form-ultimate') . '</strong>',
				'<a target="_blank" rel="noopener" href="' . esc_url(admin_url('plugin-install.php?s=Social+ Contact+Form+WPPOOL&tab=search&type=term')) . '">' . __('FormyChat', 'social-contact-form-ultimate') . '</a>'
			);
			if (!$this->scf_installed) {
				printf('<div class="notice notice-error is-dismissible"><p>%1$s</p></div>', $notice);
				return false;
			}

			$page = isset($_GET['page']) ? $_GET['page'] : '';
			if (!$this->scf_ultimate_activated && $page != 'scf-license') {
				echo '<div class="notice notice-warning"><p>' . wp_sprintf('<a class="text-indigo-500 underline" href="' . admin_url('admin.php?page=scf-license') . '">Activate License</a> for FormyChat Ultimate and access all premium features.') . '</p></div>';
			}
		}

		#is scf ultimate
		public function is_scf_ultimate()
		{
			return scf_is_true($this->appsero->license()->is_valid());
		}

		# Footer text
		public function scf_footer_text($scf_footer_text)
		{
			$footer_text = 'Thanks for using FormyChat Pro by <a href="https://wppool.dev" target="_blank">WPPOOL</a>';

			return $footer_text;
		}

		# Extend input meta 
		public function extend_scf_form_meta($scf_input_meta)
		{

			$scf_whatsapp = scf_get_option('whatsapp');
			$meta = [
				'whatsapp_number' => $scf_whatsapp['number']
			];

			if (is_user_logged_in()) {
				$meta['user_id'] = get_current_user_id();
				$user_info = get_userdata($meta['user_id']);
				$meta['user_name'] = $user_info->user_login;
				$meta['user_email'] = $user_info->user_email;
			}

			$input_meta = array_merge($scf_input_meta, $meta);

			return $input_meta;
		}


		# Localize script
		public function scf_localize_script($scf_localize_script)
		{
			$script = [
				'meta' => [
					'source' => get_the_permalink()
				]
			];

			$localize_script = array_merge($scf_localize_script, $script);

			return $localize_script;
		}

		# Fields
		public function scf_fields($scf_fields)
		{
			return $scf_fields;
		}

		# Plugin action links
		public function plugin_action_links($links)
		{

			if (function_exists('is_scf_ultimate')) {
				$links[] = '<a href="' . admin_url('admin.php?page=scf-license') . '">' . __('License', 'social-contact-form-ultimate') . '</a>';
			}
			return $links;
		}

		# Init appsero client
		public function init_appsero_client()
		{

			if (class_exists('\SocialContactFormUltimate\Appsero\Client')) {
				$this->appsero = new \SocialContactFormUltimate\Appsero\Client('6239ff91-6b41-4a6e-94a8-76a9671e13fa', 'FormyChat Ultimate', SCF_ULTIMATE_FILE);

				// Active insights
				$this->appsero->insights()->init();

				// Active automatic updater
				$this->appsero->updater();

				// Active license page and checker
				$args = array(
					'type'       => 'submenu',
					'parent_slug' => 'scf',
					'menu_title' => __((function_exists('is_scf_ultimate') && is_scf_ultimate() ? 'License' : 'Activate License'), 'social-contact-form-ultimate'),
					'page_title' => 'Manage FormyChat Ultimate License',
					'menu_slug'  => 'scf-license',
					'position'   => 99,
				);

				$this->appsero->license()->add_settings_page($args);
			}
		}

		# scf_preset_tags
		public function scf_preset_tags($scf_preset_tags)
		{
			$tags = [
				'title' => __('Title', 'social-contact-form-ultimate'),
				'url' => __('URL', 'social-contact-form-ultimate'),
				'id' => __('ID', 'social-contact-form-ultimate'),
			];

			$preset_tags = array_merge($scf_preset_tags, $tags);

			return $preset_tags;
		}
	}

	new Hooks();
endif;