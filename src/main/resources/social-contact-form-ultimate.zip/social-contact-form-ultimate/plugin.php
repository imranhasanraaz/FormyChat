<?php
/**
 * Plugin name:       FormyChat Ultimate
 * Plugin URI:        https://wppool.dev/social-contact-form-ultimate
 * Description:       Add a contact form on your website that sends form leads directly to your WhatsApp web or mobile, including WooCommerce orders, cart, etc
 * Version:           2.1.1
 * Author:            WPPOOL
 * Author URI:        https://wppool.dev
 * License:           GPLv2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       social-contact-form-ultimate
 * Domain Path:      /languages
 *
 * @package SocialContactFormUltimate
 * @since 1.0.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

// Define constants.
define('SCF_ULTIMATE_FILE', __FILE__ );

// Include boot file.
require_once plugin_dir_path( __FILE__ ) . 'includes/boot.php';